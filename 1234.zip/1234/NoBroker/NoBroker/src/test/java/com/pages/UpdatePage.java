package com.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class UpdatePage extends BasePage {

    private WebDriver driver;
    private WebDriverWait wait;

    public UpdatePage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // ✅ Initialize wait
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//*[text()='Sale']")
    WebElement salefilter;

    // @FindBy(xpath = "//*[text()='Edit']")
    // WebElement editSale;

    @FindBy(xpath = "//input[@id='rent']")
    WebElement editResale;

    @FindBy(xpath = "//*[text()='1 RK House For Sale  In Hinjawadi']")
    WebElement property;

    @FindBy(xpath = "//*[text()='Edit Property']")
    WebElement editProperty;

    @FindBy(xpath = "//*[text()='Resale Details']")
    WebElement resaleDetails;

    @FindBy(xpath = "//*[text()='Save & Continue']")
    WebElement saveEdit;

    public void updateRent(String num) {
        editResale.clear();
        editResale.sendKeys(num);
    }

    public void saveUpdates() throws InterruptedException {
        Thread.sleep(2000);
        saveEdit.click();
    }

    public void editproperty() {
        editProperty.click();
    }

    public void clickRentDetial() throws InterruptedException {
        Thread.sleep(1000);
        resaleDetails.click();
        Thread.sleep(1000);
    }

    public void clickProperty() throws InterruptedException {
        Thread.sleep(2000);
        property.click();
    }

    public void clickSale() throws InterruptedException {
        Thread.sleep(2000);
        salefilter.click();
    }

    public void clickEdit() {
        WebElement editElement = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[text()='Edit']")));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", editElement);
    }

}