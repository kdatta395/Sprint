package com.tests;

import com.driverSetup.*;
import com.pages.*;
import com.parameter.PropertyReader;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import com.aventstack.extentreports.ExtentReports; 
import com.aventstack.extentreports.ExtentTest; 
import com.util.ExtentManager;
// ...existing code...

public class Main {

    WebDriver driver;
    private HomePage homePage;
    private PostProperty postProperty;
    private FormPage formPage;
    private UpdatePage updatePage;
    ExtentReports extent;
	ExtentTest test;

    private static final String PROPERTY_PATH = "src/test/resources/PropertiesFiles/home.properties";

    // @BeforeMethod
    //     public void setUp() {
    //     BaseSteps.setup();
    //     BaseSteps.driver.get(url);

    //     homePage = new HomePage(BaseSteps.driver);
    //     postProperty = new PostProperty(BaseSteps.driver);
    //     formPage = new FormPage(BaseSteps.driver);
    //     updatePage = new UpdatePage(BaseSteps.driver);
    // }
    // --------------------------------------------------- Before Class ------------------------------------------------------------------------
	 

/**
 * Initializes the test setup before any test methods in the class are run.
 * - Sets up the WebDriver instance using BaseSteps.
 * - Loads the application URL from the properties file.
 * - Initializes the ExtentReports instance for logging.
 * - Instantiates the HomePage object for further interactions.
 */

	@BeforeClass
    public void init() {
        try {
            BaseSteps.setup();
            driver = BaseSteps.driver;

            String url = PropertyReader.getProperty(PROPERTY_PATH, "url");
            driver.get(url);

            extent = ExtentManager.getInstance();

            homePage = new HomePage(driver); // Fixed variable name

            postProperty = new PostProperty(driver);
            formPage = new FormPage(driver);
            updatePage = new UpdatePage(driver);

        } catch (Exception e) {
            System.out.println("Error in @BeforeClass init(): " + e.getMessage());
            e.printStackTrace();
        }
    }
	
	
	
// --------------------------------------------------- Before Method ------------------------------------------------------------------------
		
        // This method reloads the page before every test case
	
		@BeforeMethod
		public void resetPage() {
		    try {
		        String url = PropertyReader.getProperty(PROPERTY_PATH, "url");
		        homePage = new HomePage(BaseSteps.driver);
                postProperty = new PostProperty(BaseSteps.driver);
                formPage = new FormPage(BaseSteps.driver);
                updatePage = new UpdatePage(BaseSteps.driver);   // Reinitialize page object
		    } 
		    catch (Exception e) {
		        System.out.println("Error in @BeforeMethod resetPage(): " + e.getMessage());
		        e.printStackTrace();
		    }
		}
	
		
		                       


    @Test(priority = 1)
    public void postNewProperty() throws Exception {
        homePage.clickLogin();
        Thread.sleep(2000);
        homePage.enterDetails("9588002576");
        Thread.sleep(2000);
        homePage.waitAndClickMenu();
        Thread.sleep(2000);
        postProperty.clickProperty();
        Thread.sleep(2000);
        postProperty.clickPost();
        Thread.sleep(2000);
        postProperty.clickSelectCity();
        Thread.sleep(2000);
        postProperty.enterCity();
        Thread.sleep(2000);
        postProperty.clickPostFree();
        Thread.sleep(2000);
        formPage.aptselect("Independent House");
        Thread.sleep(2000);
        formPage.bhkselect("1 RK");
        Thread.sleep(2000);
        formPage.flrselect("Ground Only");
        Thread.sleep(2000);
        formPage.prptselect("Less than a Year");
        Thread.sleep(2000);
        formPage.facingselect("North");
        Thread.sleep(2000);
        formPage.enterBuiltUp("121");
        Thread.sleep(2000);
        formPage.clickSave();
        Thread.sleep(2000);
        postProperty.clickPreview();
        Thread.sleep(2000);
        Assert.assertTrue(true, "✅ User posted a new property successfully");
    }

    @Test(priority = 2)
    public void editProperty() throws Exception {
        homePage.clickLogin();
        Thread.sleep(2000);
        homePage.enterDetails("9588002576");
        Thread.sleep(2000);
        homePage.waitAndClickMenu();
        postProperty.clickProperty();
        Thread.sleep(5000);
        updatePage.clickSale();
        Thread.sleep(2000);
        updatePage.clickEdit();
        Thread.sleep(2000);
        updatePage.clickRentDetial();
        Thread.sleep(2000);
        updatePage.clickRentDetial();
        Thread.sleep(2000);
        updatePage.updateRent("15000000");
        Thread.sleep(2000);
        updatePage.saveUpdates();
        Thread.sleep(2000);
        postProperty.clickPreview();
        Thread.sleep(2000);
    }

    @Test(priority=3)
    public void incorrectData()throws Exception{
        homePage.clickLogin();
        Thread.sleep(2000);
        homePage.enterDetails("9588002576");
        Thread.sleep(2000);
        homePage.waitAndClickMenu();
        Thread.sleep(2000);
        postProperty.clickProperty();
        Thread.sleep(2000);
        postProperty.clickPost();
        Thread.sleep(2000);
        postProperty.clickSelectCity();
        Thread.sleep(2000);
        postProperty.enterCity();
        Thread.sleep(2000);
        postProperty.clickPostFree();
        Thread.sleep(2000);
        formPage.aptselect("Independent House");
        Thread.sleep(2000);
        formPage.bhkselect("1 RK");
        Thread.sleep(2000);
        formPage.flrselect("Ground Only");
        Thread.sleep(2000);
        formPage.prptselect("Less than a Year");
        Thread.sleep(2000);
        formPage.facingselect("North");
        Thread.sleep(2000);
        formPage.enterBuiltUp("345253");
        Thread.sleep(2000);
        formPage.clickSave();
        Thread.sleep(2000);
        Assert.assertFalse(true, "User entered incorrect details");
    }

    @Test(priority=4)
    public void invalidData()throws Exception{
         homePage.clickLogin();
        Thread.sleep(2000);
        homePage.enterDetails("9588002576");
        Thread.sleep(2000);
        homePage.waitAndClickMenu();
        Thread.sleep(2000);
        postProperty.clickProperty();
        Thread.sleep(2000);
        postProperty.clickPost();
        Thread.sleep(2000);
        postProperty.clickSelectCity();
        Thread.sleep(2000);
        postProperty.enterCity();
        Thread.sleep(2000);
        postProperty.clickPostFree();
        Thread.sleep(2000);
        formPage.aptselect("Independent House");
        Thread.sleep(2000);
        formPage.bhkselect("1 RK");
        Thread.sleep(2000);
        formPage.flrselect("Ground Only");
        Thread.sleep(2000);
        formPage.clickSave();
        Thread.sleep(2000);
        postProperty.clickPreview();
        Thread.sleep(2000);
        Assert.assertFalse(true, "User didn't fill the mandatory fields");
    }
    @AfterMethod
        public void tearDown() {
        BaseSteps.teardown();
    }
}
