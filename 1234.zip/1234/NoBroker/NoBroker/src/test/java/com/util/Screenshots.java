package com.util;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import java.io.File;

public class Screenshots {
    public static String capture(WebDriver driver, String fileName) {
        try {

        	File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        	String folderPath = "target/Reports/";
        	String filePath = folderPath + fileName + ".png";
        	File dest = new File(filePath);
        	FileUtils.copyFile(src, dest);

            return fileName+".png"; 
        } catch (Exception e) {
            e.printStackTrace();
            return null; 
        }
    }
}

