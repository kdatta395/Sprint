package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

/**
 * BasePage serves as a parent class for all page classes.
 * It provides common WebDriver and WebDriverWait setup,
 * and initializes PageFactory for WebElement binding.
 */
public abstract class BasePage {

    protected WebDriver driver;
    protected WebDriverWait wait;

    /**
     * Constructor initializes WebDriver, WebDriverWait, and PageFactory.
     * @param driver WebDriver instance passed from test class
     */
    public BasePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        PageFactory.initElements(driver, this);
    }

    /**
     * Returns the current page title.
     * @return String title of the current page
     */
    public String getPageTitle() {
        return driver.getTitle();
    }

    /**
     * Navigates to the specified URL.
     * @param url URL to open in the browser
     */
    public void navigateTo(String url) {
        driver.get(url);
    }

    /**
     * Closes the browser window.
     */
    public void closeBrowser() {
        driver.quit();
    }
}