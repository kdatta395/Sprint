package com.pages;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage extends BasePage {

   // private WebDriver driver;
    private WebDriverWait wait;

    public HomePage(WebDriver driver) {
    	super(driver);
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//div[text()='Log in']")
    WebElement loginButton;

    @FindBy(xpath = "//*[@placeholder='Enter Mobile Number']")
    WebElement mobileInput;

    @FindBy(xpath = "//*[text()='Menu']")
    WebElement menuIcon;
    
    @FindBy(xpath = "//*[text()='Continue'")
    WebElement continueLogin;

    public void clickLogin() {
//        wait.until(ExpectedConditions.elementToBeClickable(loginButton)).click();
    	loginButton.click();
    }

    public void enterDetails(String mobileNumber) throws InterruptedException {
//        wait.until(ExpectedConditions.visibilityOf(mobileInput)).clear();
        mobileInput.sendKeys(mobileNumber);
        Thread.sleep(15000);
        continueLogin.click();
        
    }

    public void waitAndClickMenu() {
//        wait.until(ExpectedConditions.elementToBeClickable(menuIcon)).click();
    	menuIcon.click();
    }
}