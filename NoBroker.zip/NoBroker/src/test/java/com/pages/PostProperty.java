package com.pages;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PostProperty extends BasePage {

    private WebDriverWait wait;

    public PostProperty(WebDriver driver) {
        super(driver);
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//*[text()='Post Your Property']")
    private WebElement postPropertyButton;

    @FindBy(xpath = "//*[text()='Start Posting Your Ad For FREE']")
    private WebElement postButton;

    @FindBy(xpath = "//div[text()='Select City']")
    private WebElement selectCityDropdown;

    @FindBy(xpath = "//input[@placeholder='Enter city']")
    private WebElement cityInput;

    @FindBy(xpath = "//button[text()='Post Free']")
    private WebElement postFreeButton;

    public void clickProperty() {
        wait.until(ExpectedConditions.elementToBeClickable(postPropertyButton)).click();
    }

    public void clickPost() {
        wait.until(ExpectedConditions.elementToBeClickable(postButton)).click();
    }

    public void clickSelectCity() {
        wait.until(ExpectedConditions.elementToBeClickable(selectCityDropdown)).click();
    }

    public void enterCity(String cityName) {
        wait.until(ExpectedConditions.visibilityOf(cityInput)).clear();
        cityInput.sendKeys(cityName);
    }

    public void clickPostFree() {
        wait.until(ExpectedConditions.elementToBeClickable(postFreeButton)).click();
    }
}