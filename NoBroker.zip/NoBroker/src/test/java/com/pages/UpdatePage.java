package com.pages;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UpdatePage extends BasePage {

    private WebDriver driver;

    public UpdatePage(WebDriver driver) {
        super(driver);
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//*[text()='Sale']")
    WebElement salefilter;

    @FindBy(xpath = "//*[text()='Edit']")
    WebElement editSale;

    @FindBy(xpath = "//input[@id='rent']")
    WebElement editRent;

    @FindBy(xpath = "//*[text()='Rental Details']")
    WebElement rentalDetails;

    @FindBy(xpath = "//input[@id='deposit']")
    WebElement depositDetails;

    @FindBy(xpath = "//*[text()='Save & Continue'")
    WebElement saveEdit;

    public void updateRent(String num) {
        rentalDetails.sendKeys(num);
    }

    public void updateDeposit(String num) {
        depositDetails.sendKeys(num);
    }

    public void saveUpdates() {
        saveEdit.click();
    }

    public void clickRentDetial() {
        rentalDetails.click();
    }

    public void clickSale() {
        salefilter.click();
    }

    public void clickEdit() {
        editSale.click();
    }
}