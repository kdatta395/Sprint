package com.parameter;

import org.testng.annotations.Test;

public class ExcelReader {
  @Test
  public void f() {
  }
}
