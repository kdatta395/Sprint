package com.parameter;

import org.testng.annotations.Test;

public class PropertyReader {
  @Test
  public void f() {
  }
}
