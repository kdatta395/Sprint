package com.tests;

import com.driverSetup.BaseSteps;
import com.pages.FormPage;
import com.pages.HomePage;
import com.pages.PostProperty;
import com.pages.UpdatePage;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class NoBroker {

    private HomePage homePage;
    private PostProperty postProperty;
    private FormPage formPage;
    private UpdatePage updatePage;

    @BeforeClass
    public void setUp() {
        BaseSteps.setup();
        BaseSteps.driver.get("https://www.nobroker.in/");

        homePage = new HomePage(BaseSteps.driver);
        postProperty = new PostProperty(BaseSteps.driver);
        formPage = new FormPage(BaseSteps.driver);
        updatePage = new UpdatePage(BaseSteps.driver);
    }

    @Test(priority = 1)
    public void loginFlow() throws InterruptedException {
        homePage.clickLogin();
        homePage.enterDetails("9588002576");
        homePage.waitAndClickMenu();
    }

    @Test(priority = 2)
    public void navigateFlow() {
        postProperty.clickProperty();
        postProperty.clickPost();
        postProperty.clickSelectCity();
        postProperty.enterCity("Pune");
        postProperty.clickPostFree();
    }

    @Test(priority = 3)
    public void fillForm() throws InterruptedException {
        formPage.aptselect("Independent House");
        Thread.sleep(2000);
        formPage.bhkselect("1 RK");
        Thread.sleep(2000);
        formPage.flrselect("Ground Only");
        Thread.sleep(2000);
        formPage.prptselect("Less than a Year");
        Thread.sleep(2000);
        formPage.facingselect("North");
        Thread.sleep(2000);
        formPage.enterBuiltUp("121");
        formPage.clickSave();

        homePage.waitAndClickMenu();
        postProperty.clickProperty();

        updatePage.clickSale();
        updatePage.clickEdit();
        updatePage.clickRentDetial();
        updatePage.updateDeposit("15000");
        updatePage.updateRent("15000");
        updatePage.saveUpdates();
    }

    @AfterClass
    public void tearDown() {
        // BaseSteps.teardown();
    }
}