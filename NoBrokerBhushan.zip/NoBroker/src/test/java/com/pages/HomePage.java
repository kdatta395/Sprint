
package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class HomePage extends BasePage {

    public HomePage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath="//*[@id=\"main-menu\"]/div[1]") 
    WebElement menuIcon;


    @FindBy(linkText = "Rent Receipts") 
    WebElement rentReceiptsLink;


//  Navigates to the Rent Receipts section of the application

    public void navigateToRentReceipts() {
    	
        wait.until(ExpectedConditions.elementToBeClickable(menuIcon)).click();               // Clicks on the menu icon to expand the navigation menu.
        wait.until(ExpectedConditions.elementToBeClickable(rentReceiptsLink)).click();       // Clicks on the Rent Receipts link to open the corresponding page. 
        
        // Waits until the tenant name input field is visible to ensure the page has loaded.
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("rentrecipt-form-tenant_name-nbInput"))); 
    }
}
