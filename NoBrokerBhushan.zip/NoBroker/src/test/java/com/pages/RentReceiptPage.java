package com.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class RentReceiptPage extends BasePage {
    public RentReceiptPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(id = "rentrecipt-form-tenant_name-nbInput")
    WebElement tenantName;

    @FindBy(name = "owner_name")
    WebElement ownerName;


	@FindBy(css = "input[placeholder='Tenant\\'s Phone']")
	WebElement tenantPhone;
	
	@FindBy(css = "input[placeholder='Owner\\'s Phone']")
	WebElement ownerPhone;
	
	@FindBy(xpath = "//input[@placeholder='Monthly Rent in Rs.']")
	WebElement rentInput;
	

	@FindBy(xpath = "//input[@placeholder=\"Owner's PAN\"]")
	WebElement ownerPan;

	
	 @FindBy(name = "tenant_address")
	 WebElement tenantAddress;
	 
	 @FindBy(name = "owner_address")
	 WebElement ownerAddress;
	
	 @FindBy(xpath = "//div[@id='rentrecipt-form-from_date-nbInput']//input[@placeholder='Receipt Start Date']")
	 WebElement startDateInput;

	 
	 @FindBy(xpath = "//div[@id='rentrecipt-form-to_date-nbInput']//input[@placeholder='Receipt Start Date']")
	 WebElement endDateInput;

	 
	 @FindBy(css = "input[type='email']")
	 WebElement emailInput;
	 
	 @FindBy(className = "submit-form")
	 WebElement submitButton;

	 

	 public void fillFormDetails(String data[]){
			tenantName.clear();
			tenantName.sendKeys(data[0]);
			
			ownerName.clear();
			ownerName.sendKeys(data[1]);
			
			tenantPhone.clear();
			tenantPhone.sendKeys(data[2]);
			
			ownerPhone.clear();
			ownerPhone.sendKeys(data[3]);
			
			rentInput.clear();
			rentInput.sendKeys(data[4]);
			
			ownerPan.clear();
			ownerPan.sendKeys(data[5]);
			
			tenantAddress.clear();
			tenantAddress.sendKeys(data[6]);
			
			ownerAddress.clear();
			ownerAddress.sendKeys(data[7]);
			
			startDateInput.clear();
			startDateInput.sendKeys(data[8]);
			startDateInput.sendKeys(Keys.ENTER);
			
			endDateInput.clear();
			endDateInput.sendKeys(data[9]);
			endDateInput.sendKeys(Keys.ENTER);
			
			emailInput.clear();
			emailInput.sendKeys(data[10]);
			

			wait.until(ExpectedConditions.elementToBeClickable(submitButton));
		    try {
		        submitButton.click(); // Trying normal click first
		    } catch (ElementClickInterceptedException e) {
		        // Fallback to JavaScript click
		        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", submitButton);
		    }
			
		} 
	 

	public String getConfirmationMessage() {
	        WebElement confirmationElement = wait.until(ExpectedConditions.visibilityOfElementLocated(
	                By.xpath("//*[contains(text(),'Your rent receipts are generated successfully')]")));
	        return confirmationElement.getText().trim();
	    }
	

	public String getValidationErrorMessage() {
	    try {
	        WebElement errorElement = wait.until(ExpectedConditions.visibilityOfElementLocated(
	                By.xpath("//*[text()='This is required field']")
	        ));
	        return errorElement.getText().trim();
	    } catch (TimeoutException e) {
	        return ""; // Element not found within timeout
	    }
	}


	public String getPANValidationErrorMessage() {
        try {
            WebElement panError = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.xpath("//*[contains(text(),'Enter Valid PAN Number')]")));
            return panError.getText().trim();
        } catch (TimeoutException e) {
            return ""; // PAN error not found
	    }
	}


	public String getDateValidationErrorMessage() {
	    try {
	        WebElement dateError = wait.until(ExpectedConditions.visibilityOfElementLocated(
	            By.xpath("//*[contains(text(),'End Date Should be greater than Start Date')]")
	        ));
	        return dateError.getText().trim();
	    } catch (TimeoutException e) {
	        return "";
	    }
	}

}