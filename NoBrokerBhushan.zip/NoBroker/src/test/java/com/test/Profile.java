package com.test;
import java.io.File;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.pages.HomePage;
import com.pages.RentReceiptPage;
import com.parameter.PropertyReader;
import com.parameter.TestDataProvider;
import com.setup.BaseSteps;
import com.util.ExtentManager;
import com.util.Screenshots;

public class Profile {
	 WebDriver driver;
	 HomePage homepage;
	 RentReceiptPage rentreceiptpage;
	 ExtentReports extent;
	 ExtentTest test;
	 
     private static final String PROPERTY_PATH = "src/test/resources/PropertiesFiles/home.properties";
     private String[] labels = {
	    "Tenant Name", "Owner Name", "Tenant Phone", "Owner Phone",
	    "Monthly Rent", "Owner PAN", "Tenant Address", "Owner Address",
	    "Start Date", "End Date", "Email"
	};

	
	

// --------------------------------------------------- Before Class ------------------------------------------------------------------------
	 

/**
 * Initializes the test setup before any test methods in the class are run.
 * - Sets up the WebDriver instance using BaseSteps.
 * - Loads the application URL from the properties file.
 * - Initializes the ExtentReports instance for logging.
 * - Instantiates the HomePage object for further interactions.
 */

	@BeforeClass
	 public void init() {
	     try {
	    	 
	         BaseSteps.setup();
	         driver = BaseSteps.driver;

	         String url = PropertyReader.getProperty(PROPERTY_PATH, "url");
	         driver.get(url);
	         
	         extent = ExtentManager.getInstance(); 
	         
	         homepage = new HomePage(driver);
	         
	     } catch (Exception e) {
	         System.out.println("Error in @BeforeClass init(): " + e.getMessage());
	         e.printStackTrace();
	     }
	 }
	
	
	
// --------------------------------------------------- Before Method ------------------------------------------------------------------------
		
        // This method reloads the page before every test case
	
		@BeforeMethod
		public void resetPage() {
		    try {
		        String url = PropertyReader.getProperty(PROPERTY_PATH, "url");
		        driver.get(url);                                   // Reload the page before each test
		        homepage = new HomePage(driver);                   // Reinitialize homepage object
        		homepage.navigateToRentReceipts();                 // Navigate to Rent Receipts page
		        rentreceiptpage = new RentReceiptPage(driver);     // Reinitialize page object
		    } 
		    catch (Exception e) {
		        System.out.println("Error in @BeforeMethod resetPage(): " + e.getMessage());
		        e.printStackTrace();
		    }
		}
	
		
		
		
// --------------------------------------------------- Test Scenario 1 ------------------------------------------------------------------------

/*
Created by: Bhushan Pisal
Reviewed by: 
Motive: To verify that when a user fills in all the required fields with valid data and clicks on the 
	    'Generate Rent Receipts' button ,the rent receipt is successfully generated and the pdf download option is available. */
		
	  @Test(priority=1, description = "Verify form submission with valid data",dataProvider = "validFormData", dataProviderClass = TestDataProvider.class)
	  public void verifyLoginWithValidData(String[] data) {
		  
			test = extent.createTest("Valid Data Submission Test");
			test.info("Test case started for valid data submission");
			for(int i=0;i<11;i++) {
				
				test.info("Entering " + labels[i] + " value: "  + data[i]);
			}
			
			rentreceiptpage.fillFormDetails(data);

		    try {
		        // Waiting for confirmation message
		        String actualMessage = rentreceiptpage.getConfirmationMessage();

		        // Capturing screenshot after confirmation appears
		        String screenshotPath = Screenshots.capture(driver, "ValidDetails");
		        test.addScreenCaptureFromPath(screenshotPath);
		        test.info("Screenshot:<br><img src='" + new File(screenshotPath).getName() + "' width='800' height='auto'/>");

		        // Asserting confirmation message
		        Assert.assertTrue(actualMessage.contains("Your rent receipts are generated successfully"),
		            "Confirmation message not found or incorrect.");
		        test.pass("Form submitted successfully with valid data.");

		    } catch (Exception e) {
		        // Handling exceptions (Timeout, Assertion)
		        String screenshotPath = Screenshots.capture(driver, "Failure_ValidDetails");
		        test.fail("Test failed due to exception: " + e.getMessage());
		        test.info("Failure Screenshot:<br><img src='" + new File(screenshotPath).getName() + "' width='800' height='auto'/>");
		        Assert.fail("Test failed due to exception: " + e.getMessage());
		    }

		}
	  
	  
	  
// --------------------------------------------------- Test Scenario 2 ------------------------------------------------------------------------
	  
/*
Created by: Bhushan Pisal
Reviewed by: 
Motive: To verify that the application shows appropriate error messages when the user clicks on the 'Generate Rent Receipts' 
	    button without filling in any of the required fields. */

	  	@Test(priority = 2, description = "Verify form submission with invalid data",dataProvider = "invalidFormData", dataProviderClass = TestDataProvider.class)
	  	public void verifyLoginWithInValidData(String[] data){
	  		
	      test = extent.createTest("Invalid Data Submission Test");
		  test.info("Test case started for required data not entered");

		  for (int i = 0; i < data.length; i++) {
			  test.info("Entering " + labels[i] + " value: " + data[i]);
		  }

	      rentreceiptpage.fillFormDetails(data);
	      
	      // Waiting for confirmation message
	      String errorMessage = rentreceiptpage.getValidationErrorMessage();
	      
	      // Capturing screenshot after confirmation appears
	      String screenshotPath = Screenshots.capture(driver, "InValidDetails");
	      test.addScreenCaptureFromPath(screenshotPath);
	      test.info("Screenshot:<br><img src='" + new File(screenshotPath).getName() + "' width='800' height='auto'/>");

			try {
					// Asserting confirmation message
			        Assert.assertEquals(errorMessage, "This is required field", "Expected validation error not found.");
			        test.pass("Validation error correctly displayed for missing required fields: This is required field");
			    } 
			catch (AssertionError e) {
					// Handling Assertion exception 
			        String failureScreenshot = Screenshots.capture(driver, "Failure_InValidDetails");
			        test.fail("Assertion failed: " + e.getMessage());
			        test.info("Failure Screenshot:<br><img src='" + new File(failureScreenshot).getName() + "' width='800' height='auto'/>");
			        throw e;
			    }

	  	}
	  	
	  	
	  
// --------------------------------------------------- Test Scenario 3 ------------------------------------------------------------------------

/*
Created by: Bhushan Pisal
Reviewed by: 
Motive: To verify that the application shows an error message when the user enters an invalid PAN number format in the form 
        and attempts to generate receipt. */
	  	
	  	
	  @Test(priority = 3, description = "Verify PAN field with invalid format",dataProvider = "invalidPANFormat", dataProviderClass = TestDataProvider.class)
	  public void verifyInvalidPANFormat(String[] data ){
		  
        test = extent.createTest("Invalid PAN Format Test");
		test.info("Test Case Started for Invalid PAN Submission");
     
        for (int i = 0; i < 11; i++) {
            test.info("Entering " + labels[i] + " value: "  + data[i]);
        }

        rentreceiptpage.fillFormDetails(data);

        // Get PAN error message 
        String panErrorMessage = rentreceiptpage.getPANValidationErrorMessage();

        // Capturing screenshot after getting PAN error message
        String screenshotPath = Screenshots.capture(driver, "InvalidPANFormat");
        test.addScreenCaptureFromPath(screenshotPath);
        test.info("Screenshot:<br><img src='" + new File(screenshotPath).getName() + "' width='800' height='auto'/>");

        try {
        	// Asserting PAN error message
            Assert.assertTrue(panErrorMessage.contains("Enter Valid PAN Number"),"PAN validation error not displayed correctly.");
            test.pass("Correct error message displayed for invalid PAN format: Enter Valid PAN Number");
        } 
        catch (AssertionError e) {
        	// Handling Assertion exception 
            String failureScreenshot = Screenshots.capture(driver, "Failure_InvalidPANFormat");
            test.fail("Assertion failed: " + e.getMessage());
            test.info("Failure Screenshot:<br><img src='" + new File(failureScreenshot).getName() + "' width='800' height='auto'/>");
            throw e;
        }

    }

	  

// --------------------------------------------------- Test Scenario 4 ------------------------------------------------------------------------

/*
Created by: Bhushan Pisal
Reviewed by: 
Motive: To verify that the application shows an error message when the receipt end date is less than the receipt start date. */
	  	  	
	  	@Test(priority = 4, description = "Verify error when receipt end date is before start date",dataProvider = "invalidEndDate", dataProviderClass = TestDataProvider.class)
		public void verifyEndDateBeforeStartDate(String[] data ){
			
		    test = extent.createTest("End Date less than Start Date Test");
		    test.info("Test case started for invalid enddate submission");
		
		    for (int i = 0; i < 11; i++) {
		        test.info("Entering " + labels[i] + " value: "  + data[i]);
		    }
		
		    rentreceiptpage.fillFormDetails(data);
	
		    // Waiting for date validation error message
		    String dateErrorMessage = rentreceiptpage.getDateValidationErrorMessage();
		
		    // Capturing screenshot after getting date validation message
		    String screenshotPath = Screenshots.capture(driver, "EndDateBeforeStartDate");
		    test.addScreenCaptureFromPath(screenshotPath);
		    test.info("Screenshot:<br><img src='" + new File(screenshotPath).getName() + "' width='800' height='auto'/>");
	
	
			try {
				 // Asserting date validation error message
			     Assert.assertTrue(dateErrorMessage.contains("End Date Should be greater than Start Date"),"Expected date validation error not displayed.");
			     test.pass("Correct error message displayed when end date is before start date: End Date Should be greater than Start Date");
		    } 
			catch (AssertionError e) {
				// Handling Assertion exception 
			    String failureScreenshot = Screenshots.capture(driver, "Failure_EndDateBeforeStartDate");
			    test.fail("Assertion failed: " + e.getMessage());
			    test.info("Failure Screenshot:<br><img src='" + new File(failureScreenshot).getName() + "' width='800' height='auto'/>");
			    throw e;
		    }

		}
	  	
	  	
	  	
	  	
// --------------------------------------------------- Test Scenario 5 ------------------------------------------------------------------------

/*
Created by: Bhushan Pisal
Reviewed by: 
Motive: To verify that the application shows an error message when the user enters an invalid phone number in the form and attempts to generate receipt. */
	  		  	
	  	@Test(priority = 5, description = "Verify receipt is not generated with invalid phone number",dataProvider = "invalidPhone", dataProviderClass = TestDataProvider.class)
		public void verifyReceiptNotGeneratedWithInvalidPhone(String[] data ) {
			
		    test = extent.createTest("Receipt Generation with Invalid Phone Number");
		    test.info("Test case started for invalid phone number submission");
		   
		    for (int i = 0; i < 11; i++) {
		        test.info("Entering " + labels[i] + " value: "  + data[i]);
		    }

		    rentreceiptpage.fillFormDetails(data);


			try {
				// Waiting for confirmation message
			    String confirmationMessage = rentreceiptpage.getConfirmationMessage();
			    test.info("Confirmation Message received: " + confirmationMessage);
			
			    // Capturing screenshot after confirmation appears
			    String screenshotPath = Screenshots.capture(driver, "InvalidPhoneReceipt");
			    test.addScreenCaptureFromPath(screenshotPath);
			    test.info("Screenshot:<br><img src='" + new File(screenshotPath).getName() + "' width='800' height='auto'/>");
			
			    // Asserting phone validation error message
			    Assert.assertFalse(confirmationMessage.contains("Your rent receipts are generated successfully"),
			        "Receipt should not be generated with invalid phone number.");
			
			    test.pass("Receipt was not generated with invalid phone number as expected.");
			
			} catch (AssertionError e) {
				// Handling exceptions (Timeout, Assertion)
			    String failureScreenshot = Screenshots.capture(driver, "Failure_InvalidPhoneReceipt");
			    test.fail("Test failed: " + e);
			    test.info("Failure Screenshot:<br><img src='" + new File(failureScreenshot).getName() + "' width='800' height='auto'/>");
			    throw e; 
			}
			
		}
		
	
// -------------------------------------------------------------- After Method  ------------------------------------------------------------------------
		   	
	  	
	  	@AfterMethod
		public void reportTestCompletion(ITestResult result) {

			if(result.getStatus() == ITestResult.SUCCESS) {

				test.pass("Test Case Completed : Passed");

			}

			else if(result.getStatus() == ITestResult.FAILURE) {

				test.fail("Test Case Completed : Failed ");

			}

			else if(result.getStatus() == ITestResult.SKIP) {

				test.skip("Test Skipped" + result.getThrowable().getMessage());

			}

		}

	 
// --------------------------------------------------- After Class ------------------------------------------------------------------------
	 

/**
 * Cleans up resources after all test methods in the class have run.
 * - Tears down the WebDriver instance to close the browser and release resources.
 * - Flushes the ExtentReports to ensure all logs are written to the report file.
 */

	  	@AfterClass
	    public void cleanup() {
	        BaseSteps.teardown();
	        extent.flush(); 
	    }
	    
}
