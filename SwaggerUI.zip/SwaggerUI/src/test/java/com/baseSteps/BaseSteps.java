package com.baseSteps;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import io.restassured.RestAssured;

public class BaseSteps {
	
	public static void setup() throws IOException
	{
		
//		load() ==> Properties
		Properties p = new Properties();
		
//		Extract the Base URI
		FileInputStream fis = 
				new FileInputStream("C:\\Users\\udayk\\SeleniumWebDriver\\APISprintProject\\src\\test\\resource\\PropertyFile\\APIURI.properties");
		
		p.load(fis);
//		baseURI=https://api.restful-api.dev ==> MEMORY
		 
		RestAssured.baseURI	= 
				p.getProperty("baseURI");
			
	}
}

