package com.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.http.ContentType;

import org.testng.Assert;
import org.testng.annotations.*;

import com.aventstack.extentreports.*;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.utils.ExtentManager;

import java.util.List;

import org.json.JSONObject;

public class BookStoreAPITest {

    ExtentReports extent;
    ExtentTest test;
    String baseURL = "https://bookstore.toolsqa.com";
    String userName = "MaheshDarg9";
    String password = "Mahesh@123";
    String token;
    String userId;
    String isbn1 = "9781449325862";
    String isbn2 = "9781449365035";

    @BeforeClass
    public void setupReport() {
    	extent = ExtentManager.getInstance();
    }

    @BeforeMethod
    public void sslreport()
    {
    	RestAssured.useRelaxedHTTPSValidation();
    }
    
    @Test(priority = 1)
    public void createUser() {
        test = extent.createTest("Create User");

        JSONObject payload = new JSONObject();
        payload.put("userName", userName);
        payload.put("password", password);

        Response response = RestAssured
            .given().contentType(ContentType.JSON)
            .body(payload.toString())
            .post(baseURL + "/Account/v1/User");

        Assert.assertEquals(response.getStatusCode(), 201);
        userId = response.jsonPath().getString("userID");
        test.pass("User created with ID: " + userId);
    }

    @Test(priority = 2)
    public void generateToken() {
        test = extent.createTest("Generate Token");

        JSONObject payload = new JSONObject();
        payload.put("userName", userName);
        payload.put("password", password);

        Response response = RestAssured
            .given().contentType(ContentType.JSON)
            .body(payload.toString())
            .post(baseURL + "/Account/v1/GenerateToken");

        Assert.assertEquals(response.getStatusCode(), 200);
        token = response.jsonPath().getString("token");
        test.pass("Token generated: " + token);
    }

    @Test(priority = 3)
    public void authorizeUser() {
        test = extent.createTest("Authorize User");

        JSONObject payload = new JSONObject();
        payload.put("userName", userName);
        payload.put("password", password);

        Response response = RestAssured
            .given().contentType(ContentType.JSON)
            .body(payload.toString())
            .post(baseURL + "/Account/v1/Authorized");

        Assert.assertEquals(response.getStatusCode(), 200);
        Assert.assertTrue(response.asString().contains("true"));
        test.pass("User authorized successfully");
    }

    @Test(priority = 4)
    public void addBooksToUser() {
        test = extent.createTest("Add Books to User");

        JSONObject book1 = new JSONObject();
        book1.put("isbn", isbn1);

        JSONObject book2 = new JSONObject();
        book2.put("isbn", isbn2);

        JSONObject payload = new JSONObject();
        payload.put("userId", userId);
        payload.put("collectionOfIsbns", List.of(book1, book2));

        Response response = RestAssured
            .given().contentType(ContentType.JSON)
            .header("Authorization", "Bearer " + token)
            .body(payload.toString())
            .post(baseURL + "/BookStore/v1/Books");

        Assert.assertEquals(response.getStatusCode(), 201);
        test.pass("Books added successfully");
    }

    @Test(priority = 5)
    public void verifyBooksInUserCollection() {
        test = extent.createTest("Verify Books in User Collection");

        Response response = RestAssured
            .given().header("Authorization", "Bearer " + token)
            .get(baseURL + "/Account/v1/User/" + userId);

        Assert.assertEquals(response.getStatusCode(), 200);
        Assert.assertTrue(response.asString().contains(isbn1));
        test.pass("Books verified in user collection");
    }

    @Test(priority = 6)
    public void deleteBooksFromUser() {
        test = extent.createTest("Delete All Books");

        Response response = RestAssured
            .given().header("Authorization", "Bearer " + token)
            .queryParam("UserId", userId)
            .delete(baseURL + "/BookStore/v1/Books");

        Assert.assertEquals(response.getStatusCode(), 204);
        test.pass("Books deleted successfully");
    }

    @Test(priority = 7)
    public void verifyNoBooksRemain() {
        test = extent.createTest("Verify No Books Remain");

        Response response = RestAssured
            .given().header("Authorization", "Bearer " + token)
            .get(baseURL + "/Account/v1/User/" + userId);

        Assert.assertEquals(response.getStatusCode(), 200);
        Assert.assertTrue(response.jsonPath().getList("books").isEmpty());
        test.pass("No books found in user collection");
    }

    @AfterClass
    public void tearDownReport() {
        extent.flush();
    }
}