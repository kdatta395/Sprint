package com.pages;

import org.openqa.selenium.WebDriver;

import java.util.ArrayList;

public class BasePage {
    protected WebDriver driver;

    public BasePage(WebDriver driver) {
        this.driver = driver;
    }

    // Reusable tab switch method
    public void switchToNewTab() {
        ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
        if (tabs.size() > 1) {
            driver.switchTo().window(tabs.get(1)); // Switch to second tab
        }
    }
}
