package com.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FormPage {

    private WebDriver driver;

    public FormPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "(//div[@class='css-1hwfws3 nb-select__value-container'])[1]")
    private WebElement aptDropdown;

    @FindBy(xpath = "(//div[@class='css-1hwfws3 nb-select__value-container'])[1]")
    private WebElement bhkDropdown;

    @FindBy(xpath = "(//div[@class='css-1hwfws3 nb-select__value-container'])[1]")
    private WebElement floorDropdown;

    @FindBy(xpath = "(//div[@class='css-1hwfws3 nb-select__value-container'])[1]")
    private WebElement ageDropdown;

    @FindBy(xpath = "(//div[@class='css-1hwfws3 nb-select__value-container'])[1]")
    private WebElement facingDropdown;

    @FindBy(xpath = "//input[@placeholder='Built Up Area']")
    private WebElement builtUpInput;

    @FindBy(xpath = "//*[text()='Save & Continue']")
    private WebElement saveButton;

    private void selectFromDropdown(WebElement dropdown, String optionText) {
        try {
            dropdown.click();
            Thread.sleep(1000); // Allow options to render

            By optionLocator = By.xpath("//*[contains(text(),'" + optionText + "')]");
            WebElement option = driver.findElement(optionLocator);
            option.click();
        } catch (Exception e) {
            System.out.println("❌ Failed to select '" + optionText + "': " + e.getMessage());
        }
    }

    public void aptselect(String option) {
        selectFromDropdown(aptDropdown, option);
    }

    public void bhkselect(String option) {
        selectFromDropdown(bhkDropdown, option);
    }

    public void flrselect(String option) {
        selectFromDropdown(floorDropdown, option);
    }

    public void prptselect(String option) {
        selectFromDropdown(ageDropdown, option);
    }

    public void facingselect(String option) {
        selectFromDropdown(facingDropdown, option);
    }

    public void enterBuiltUp(String area) {
        builtUpInput.clear();
        builtUpInput.sendKeys(area);
    }

    public void clickSave() {
        saveButton.click();
    }
}