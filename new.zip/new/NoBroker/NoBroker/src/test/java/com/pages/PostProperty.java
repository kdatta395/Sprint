package com.pages;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PostProperty extends BasePage {

    private WebDriverWait wait;

    public PostProperty(WebDriver driver) {
        super(driver);
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//*[text()='Post Your Property']")
    private WebElement postPropertyButton;

    @FindBy(xpath = "//*[text()='Post Now']")
    private WebElement postButton;

    @FindBy(xpath = "//div[text()='Select City']")
    private WebElement selectCityDropdown;

    @FindBy(xpath = "//button[text()='Start Posting Your Ad For FREE']")
    private WebElement postFreeButton;
    
    @FindBy(xpath ="//*[contains(text(), 'Pune')]")
    WebElement cityPune;

    @FindBy(xpath = "//*[text()='Preview']")
    WebElement preview;

    public void clickPreview(){
        preview.click();
    }
    public void clickProperty() {
        postPropertyButton.click();
        switchToNewTab(); // Handle new tab immediately
    }

    public void clickPost() {
        wait.until(ExpectedConditions.visibilityOf(postButton));
        ((org.openqa.selenium.JavascriptExecutor) driver)
                .executeScript("arguments[0].scrollIntoView({block: 'center'});", postButton);
        wait.until(ExpectedConditions.elementToBeClickable(postButton)).click();
    }

    public void clickSelectCity() {
        wait.until(ExpectedConditions.elementToBeClickable(selectCityDropdown)).click();
    }

    public void enterCity()throws Exception{
        cityPune.click();
    }

    public void clickPostFree() {
        wait.until(ExpectedConditions.elementToBeClickable(postFreeButton)).click();
    }
}
