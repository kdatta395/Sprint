
package com.parameter;

import org.testng.annotations.DataProvider;

public class TestDataProvider {
	
		private static final String EXCEL_PATH = "src/test/resources/ExcelData/ExcelData.xlsx";
		
		
		@DataProvider(name = "validFormData")
		public static Object[][] getvalidFormData() {
		    String[] data = new String[11];
		    for (int i = 0; i < 11; i++) {
		        data[i] = ExcelReader.getCellValue(EXCEL_PATH, 1, i);
		    }
		    return new Object[][] { { data } };
		}
		
		
		@DataProvider(name = "invalidFormData")
		    public static Object[][] getInvalidFormData() {
		        String[] data = new String[11];
		        for (int i = 0; i < 11; i++) {
		            data[i] = ExcelReader.getCellValue(EXCEL_PATH, 2, i);
		        }
		        return new Object[][] { { data } };
		    }
		
		
		@DataProvider(name = "invalidPANFormat")
		public static Object[][] getInvalidPANFormat() {
		    String[] data = new String[11];
		    for (int i = 0; i < 11; i++) {
		        data[i] = ExcelReader.getCellValue(EXCEL_PATH, 3, i);
		    }
		    return new Object[][] { { data } };
		}
		
		
		@DataProvider(name = "invalidEndDate")
		public static Object[][] getInvalidEndData() {
		    String[] data = new String[11];
		    for (int i = 0; i < 11; i++) {
		        data[i] = ExcelReader.getCellValue(EXCEL_PATH, 4, i);
		    }
		    return new Object[][] { { data } };
		}
		
		
		@DataProvider(name = "invalidPhone")
		public static Object[][] getInvalidPhone() {
		    String[] data = new String[11];
		    for (int i = 0; i < 11; i++) {
		        data[i] = ExcelReader.getCellValue(EXCEL_PATH, 5, i);
		    }
		    return new Object[][] { { data } };
		}

}